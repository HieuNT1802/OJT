module OOP_DAY1 {
}
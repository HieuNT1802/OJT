package fa.training.entities;

public class Magazine extends Publication{
 private String author;
 private int volumn;
 private int edition;
 
	
	
	@Override
	public void display() {
		// TODO Auto-generated method stub
		
	}

}

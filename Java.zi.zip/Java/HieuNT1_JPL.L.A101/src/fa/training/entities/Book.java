package fa.training.entities;

import java.util.Date;
import java.util.Set;

public class Book extends Publication {
 private String isbn;
 private Set<String> author;
 private String publicationPlace;
 
public Book() {
	super();
	// TODO Auto-generated constructor stub
}

public Book(int pubicationYear, String publisher, Date publicationDate) {
	super(pubicationYear, publisher, publicationDate);
	// TODO Auto-generated constructor stub
}

public Book(int pubicationYear, String publisher, Date publicationDate, String isbn, Set<String> author,
		String publicationPlace) {
	super(pubicationYear, publisher, publicationDate);
	this.isbn = isbn;
	this.author = author;
	this.publicationPlace = publicationPlace;
}

@Override
public String toString() {
	return "Book [isbn=" + isbn + ", author=" + author + ", publicationPlace=" + publicationPlace + "]";
}

@Override
public void display() {
	// TODO Auto-generated method stub
	
}
 
}

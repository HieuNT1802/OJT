/**
 * 
 */
/**
 * @author ADMIN
 *
 */
module HieuNT1_OOP_Practice_2 {
}
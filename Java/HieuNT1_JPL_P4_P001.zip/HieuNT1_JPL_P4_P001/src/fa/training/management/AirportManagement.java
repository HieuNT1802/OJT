package fa.training.management;

public class AirportManagement {
	private static void showMenu() {
		System.out.println("1. Create Airport");
		System.out.println("2. Delete Airport");
		System.out.println("3. Add Airplane to airport");
		System.out.println("4. ");
		System.out.println("5. ");
		System.out.println("6. Quit");
	}
}

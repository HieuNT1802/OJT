package fa.training.assignment1;

public class ArithmeticExercise2 {
public static void main(String[] args) {
	int number1=125;
	int number2=24;
	System.out.println("125 + 24 = " + (number1+number2));
	System.out.println("125 - 24 = " + (number1-number2));
	System.out.println("125 x 24 = " + (number1*number2));
	System.out.println("125 / 24 = " + (number1/number2));
	System.out.println("125 % 24 = " + (number1%number2));
}
}

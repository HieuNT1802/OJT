package fa.tranning.ex2;

import java.util.List;


public class Department {
  private String deptName;
  private List<Employee> employees;


}

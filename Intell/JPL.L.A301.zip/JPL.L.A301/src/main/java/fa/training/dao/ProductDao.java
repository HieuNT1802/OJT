package fa.training.dao;

public interface ProductDao {
}

package fa.training.dao;

public interface EmployeeDAO {
}
